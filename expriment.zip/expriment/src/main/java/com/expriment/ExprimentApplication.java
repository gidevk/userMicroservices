package com.expriment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExprimentApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExprimentApplication.class, args);
	}

}
